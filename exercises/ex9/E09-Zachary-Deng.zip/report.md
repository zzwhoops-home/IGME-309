# Exercise 9 - Transformations

This exercise was different from other assignments, in the sense that we did not have to do any coding. One thing I did relearn was that matrix transformations are applied from right to left. I thought it helpful to think of a composition of transformations as being applied to some vector v. That way, it makes more sense to say that okay, the matrix "touching" the vector is applied to that vector. The next matrix is then applied to that product, hence going from right to left.

I also learned how you can build rotation and translation matrices. The latter, especially, was interesting to think about augmenting a 2D vector into a 3D vector with z=1 as the third component in order to make the translation work as a product.
