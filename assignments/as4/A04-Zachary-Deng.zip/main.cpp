//Usage:
//Hold down the number keys , 1-7, to select one or multiple circles.
//While circle(s) are selected, use the left mouse button to translate and use the right mouse button to rotate.

#ifdef __APPLE__
#include <GLUT/glut.h>
#else
#include <GL/freeglut.h>
#endif

#include <iostream>
#include <math.h>
using namespace std;

#define NUM_SHAPES 16
#define CIRCLE_RADIUM 2.0

int win_width = 600, win_height = 600;
float canvas_width = 20.0f; float canvas_height = 20.0f;

bool keyStates[256];
int buttonState;

int selectedShape = 0;
int totalShapes = 0;
float rotationAmount = 5.0f;

float shapes[4 * NUM_SHAPES];
float colors[3 * NUM_SHAPES];
float translations[2 * NUM_SHAPES];
float rotations[NUM_SHAPES];

float curMouse[2];
float preMouse[2];

void addRectToShapes(float localX, float localY, float w, float h, float translateX, float translateY)
{
    shapes[totalShapes * 4 + 0] = localX;
    shapes[totalShapes * 4 + 1] = localY;
    shapes[totalShapes * 4 + 2] = w;
    shapes[totalShapes * 4 + 3] = h;

    translations[totalShapes * 2 + 0] = translateX;
    translations[totalShapes * 2 + 1] = translateY;

    totalShapes++;
}

void resetColor(int index) {
    colors[index * 3 + 0] = 0.0f;
    colors[index * 3 + 1] = 0.0f;
    colors[index * 3 + 2] = 0.0f;
    glutPostRedisplay();
}

void selectColor(int index) {
    colors[index * 3 + 0] = 1.0f;
    colors[index * 3 + 1] = 0.0f;
    colors[index * 3 + 2] = 0.0f;
    glutPostRedisplay();
}

void init(void)
{
    for (int i = 0; i < 256; i++) {
        keyStates[i] = false;
    }

    for (int i = 0; i < NUM_SHAPES; i++) {
        colors[i * 3 + 0] = 0.0f; // red
        colors[i * 3 + 1] = 0.0f; // green
        colors[i * 3 + 2] = 0.0f; // blue

        translations[i * 2 + 0] = 0.0f; // x
        translations[i * 2 + 1] = 0.0f; // y

        rotations[i] = 0.0f;
    }

    int i = 0;
    // torso is center (first transform)
    addRectToShapes(0.0, 0.0, 3.0, 2.0, 0.0, 0.0);

    // chest connected to torso (2nd transform)
    addRectToShapes(0.0, 0.0, 4.0, 2.0, 0.0, 2.0);

    // neck to chest
    addRectToShapes(0.0, 0.0, 0.5, 1.0, 0.0, 2.0);

    // head to neck
    addRectToShapes(0.0, 0.0, 2.0, 2.0, 0.0, 1.0);

    // l upper arm to chest
    addRectToShapes(0.0, 0.0, 1.8, 0.7, 2.0, 1.0);
    // l lower arm to l upper arm
    addRectToShapes(0.0, 0.0, 1.8, 0.7, 1.8, 0.0);
    // l hand to l lower arm
    addRectToShapes(0.0, 0.0, 1.3, 1.5, 1.8, 0.0);

    // r upper arm to chest
    addRectToShapes(0.0, 0.0, 1.8, 0.7, -2.0, 1.0);
    // r lower arm to r upper arm
    addRectToShapes(0.0, 0.0, 1.8, 0.7, -1.8, 0.0);
    // r hand to r lower arm
    addRectToShapes(0.0, 0.0, 1.3, 1.5, -1.8, 0.0);

    // l upper leg to torso
    addRectToShapes(0.0, 0.0, 0.8, 3.0, -0.6, 0.0);
    // l lower leg to l upper leg
    addRectToShapes(0.0, 0.0, 0.8, 3.0, 0.0, -3.0);
    // l foot to l lower leg
    addRectToShapes(0.0, 0.0, 1.0, 1.0, 0.0, -3.0);

    // u upper leg to torso
    addRectToShapes(0.0, 0.0, 0.8, 3.0, 0.6, 0.0);
    // u lower leg to u upper leg
    addRectToShapes(0.0, 0.0, 0.8, 3.0, 0.0, -3.0);
    // u foot to u lower leg
    addRectToShapes(0.0, 0.0, 1.0, 1.0, 0.0, -3.0);

    buttonState = -1;
}

void drawCircle(float radius, const float* c)
{
    glColor3fv(c);
    glLineWidth(3.0f);
    glBegin(GL_LINE_STRIP);
    for (int i = 0; i <= 100; i++)
        glVertex2f(radius * cosf(3.14 * 2 / 100 * i), radius * sinf(3.14 * 2 / 100 * i));
    glEnd();
}

// from top-left corner
void drawRect(float* shapePtr, float* curColors)
{
    float x = *shapePtr;
    float y = *(shapePtr + 1);
    float width = *(shapePtr + 2);
    float height = *(shapePtr + 3);

    glColor3fv(curColors);
    glLineWidth(3.0f);
    glBegin(GL_LINE_LOOP);
        glVertex2f(x, y);
        glVertex2f(x + width, y);
        glVertex2f(x + width, y + height);
        glVertex2f(x, y + height);
    glEnd();
}

void drawTransformed(int i, float anchorChar) {
    float width = shapes[i * 4 + 2];
    float height = shapes[i * 4 + 3];

    glTranslatef(translations[i * 2 + 0], translations[i * 2 + 1], 0.0f);
    glRotatef(rotations[i], 0.0f, 0.0f, 1.0f);

    glPushMatrix();
    if (anchorChar == 'b') {
        glTranslatef(-width / 2.0f, 0.0f, 0.0f);
    }
    else if (anchorChar == 'l') {
        glTranslatef(0.0f, -height / 2.0f, 0.0f);
    }
    else if (anchorChar == 'r') {
        glTranslatef(-width, -height / 2.0f, 0.0f);
    }
    else if (anchorChar == 't') {
        glTranslatef(-width / 2.0f, -height, 0.0f);
    }
    drawRect(shapes + (i * 4), colors + (i * 3));
    glPopMatrix();
}

void display(void)
{
    glClearColor(1.0, 1.0, 1.0, 0.0);
    glClear(GL_COLOR_BUFFER_BIT);

    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();

    // now I could set up a struct to manage children, but let's just do it the dumb hard-coded way 
    int i = 0;

    // torso is center (first transform)
    drawTransformed(i, 'b');
    glPushMatrix();

    // chest connected to torso (2nd transform)
    drawTransformed(++i, 'b');

        // neck to chest
        glPushMatrix();
            drawTransformed(++i, 'b');

            // head to neck
            drawTransformed(++i, 'b');
        glPopMatrix();

        // l upper arm to chest
        glPushMatrix();
            drawTransformed(++i, 'l');
            // l lower arm to l upper arm
            drawTransformed(++i, 'l');
            // l hand to l lower arm
            drawTransformed(++i, 'l');
        glPopMatrix();


        // r upper arm to chest
        glPushMatrix();
            drawTransformed(++i, 'r');
            // r lower arm to r upper arm
            drawTransformed(++i, 'r');
            // r hand to r lower arm
            drawTransformed(++i, 'r');
        glPopMatrix();
    glPopMatrix();

    // l upper leg to torso
    glPushMatrix();
        drawTransformed(++i, 't');
        // l lower leg to l upper leg
        drawTransformed(++i, 't');
        // l foot to l lower leg
        drawTransformed(++i, 't');
    glPopMatrix();

    // u upper leg to torso
    glPushMatrix();
        drawTransformed(++i, 't');
        // u lower leg to u upper leg
        drawTransformed(++i, 't');
        // u foot to u lower leg
        drawTransformed(++i, 't');
    glPopMatrix();

    // the following codes could be written in a for loop.
    // Here I expand them so that you can better trace the changes of cirlce's coordinate system.

    //int cid = -1; // the index of current circle
    //// circle 0
    //cid = 0;
    //glTranslatef(translations[cid * 2 + 0], translations[cid * 2 + 1], 0.0f);
    //glRotatef(rotations[cid], 0.0f, 0.0f, 1.0f);
    //drawCircle(CIRCLE_RADIUM * (MAX_NUM_CIRCLE - cid) / MAX_NUM_CIRCLE, colors + cid * 3);

    //// circle 1
    //cid = 1;
    //glTranslatef(translations[cid * 2 + 0], translations[cid * 2 + 1], 0.0f);
    //glRotatef(rotations[cid], 0.0f, 0.0f, 1.0f);
    //drawCircle(CIRCLE_RADIUM * (MAX_NUM_CIRCLE - cid) / MAX_NUM_CIRCLE, colors + cid * 3);

    //// circle 2
    //cid = 2;
    //glTranslatef(translations[cid * 2 + 0], translations[cid * 2 + 1], 0.0f);
    //glRotatef(rotations[cid], 0.0f, 0.0f, 1.0f);
    //drawCircle(CIRCLE_RADIUM * (MAX_NUM_CIRCLE - cid) / MAX_NUM_CIRCLE, colors + cid * 3);

    //// circle 3
    //cid = 3;
    //glTranslatef(translations[cid * 2 + 0], translations[cid * 2 + 1], 0.0f);
    //glRotatef(rotations[cid], 0.0f, 0.0f, 1.0f);
    //glPushMatrix(); // push the circle 1's CS to the modelview stack
    //drawCircle(CIRCLE_RADIUM * (MAX_NUM_CIRCLE - cid) / MAX_NUM_CIRCLE, colors + cid * 3);

    //// circle 4
    //cid = 4;
    //glTranslatef(translations[cid * 2 + 0], translations[cid * 2 + 1], 0.0f);
    //glRotatef(rotations[cid], 0.0f, 0.0f, 1.0f);
    //drawCircle(CIRCLE_RADIUM * (MAX_NUM_CIRCLE - cid) / MAX_NUM_CIRCLE, colors + cid * 3);
    //glPopMatrix(); // back to the CS of Circle 1

    //// circle 5
    //cid = 5;
    //glTranslatef(translations[cid * 2 + 0], translations[cid * 2 + 1], 0.0f);
    //glRotatef(rotations[cid], 0.0f, 0.0f, 1.0f);
    //drawCircle(CIRCLE_RADIUM * (MAX_NUM_CIRCLE - cid) / MAX_NUM_CIRCLE, colors + cid * 3);


    glutSwapBuffers();
}

void reshape(int w, int h)
{
    win_width = w;
    win_height = h;

    glMatrixMode(GL_PROJECTION);
    glLoadIdentity();
    gluOrtho2D(-canvas_width / 2.0f, canvas_width / 2.0f, -canvas_height / 2.0f, canvas_height / 2.0f);
    glViewport(0, 0, (GLsizei)win_width, (GLsizei)win_height);

    glutPostRedisplay();
}


void keyboard(unsigned char key, int x, int y)
{
    if (key == 27) // 'esc' key
        exit(0);

    unsigned char asciiOffset = 49; // see an ascii table

    cout << selectedShape << endl;
    if (key == 'a') {
        rotations[selectedShape] += rotationAmount;
    }
    else if (key == 'd') {
        rotations[selectedShape] -= rotationAmount;
    }

    glutPostRedisplay();
}

void specialKeyHandler(int key, int x, int y)
{
    if (key == GLUT_KEY_UP) {
        if (selectedShape + 1 < totalShapes) {
            resetColor(selectedShape);

            selectedShape++;

            selectColor(selectedShape);
        }
    }
    else if (key == GLUT_KEY_DOWN) {
        if (selectedShape - 1 >= 0) {
            resetColor(selectedShape);

            selectedShape--;

            selectColor(selectedShape);
        }
    }
}

int main(int argc, char* argv[])
{
    init();
    glutInit(&argc, argv);
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
    glutInitWindowSize(win_width, win_height);
    glutCreateWindow("2D Transformation Tree");

    // initial color of torso selected
    selectColor(0);

    glutReshapeFunc(reshape);
    glutDisplayFunc(display);
    glutKeyboardFunc(keyboard);
    glutSpecialFunc(specialKeyHandler);
    glutMainLoop();
    return 0;

}
